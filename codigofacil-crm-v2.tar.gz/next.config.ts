import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Clean configuration for production deployment
};

export default nextConfig;
